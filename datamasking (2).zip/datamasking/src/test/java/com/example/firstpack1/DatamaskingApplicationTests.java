package com.example.firstpack1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatamaskingApplicationTests {

	@Test
	void contextLoads() {
	}

}
