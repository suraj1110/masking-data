package com.example.masking.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.masking.entity.UserData;
import com.example.masking.services.MaskingServices;

@RestController
public class MyController {
	
	@GetMapping("/email")
	public String myEmail() throws Exception {
		return MaskingServices.maskEmail(UserData.email, '*');
	}
	@GetMapping("/password")

	public String myPassword() {
		return MaskingServices.maskPassword(UserData.password,20);
	}
	@GetMapping("/credit")
	public String home(@RequestBody UserData emp) throws Exception {

		return MaskingServices.maskCardNumber(UserData.credit_card, "xxxx-xxxx-xxxx-####");
	}
	@GetMapping("/Get")
	public String myAllData(@RequestBody UserData emp) throws Exception  {
//	return MaskingServices.myLogs();
	return MaskingServices.getMasking();
	}
	
}
