package com.example.masking.entity;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class UserData {

	public static String credit_card ;
	public static String email ;
	public static String password;
	public static String username;
	public static int id = 11;	
	//Getter and Setter
	public static String getCredit_card() {
		return credit_card;
	}
	public void setCredit_card(String credit_card) {
		UserData.credit_card = credit_card;
	}
	public static String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		UserData.email = email;
	}
	public static String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		UserData.password = password;
	}
	public static String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		UserData.username = username;
	}

	public UserData(String credit_card,String email,String password ,String username) {

		UserData.credit_card = credit_card;
		UserData.email = email;
		UserData.password = password;
		UserData.username = username;
	}
	public UserData() {
		
	}
}
