package com.example.masking.services;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.example.masking.entity.UserData;

public class MaskingServices {

	private static final Logger logger = LogManager.getLogger(MaskingServices.class);

	//Credit_Card Masking Method 
	public static String maskCardNumber(String cardNumber, String mask) {
		int index = 0;
		StringBuilder maskedNumber = new StringBuilder();
		for (int i = 0; i < mask.length(); i++) {
			char c = mask.charAt(i);
			if (c == '#') {
				maskedNumber.append(cardNumber.charAt(index));
				index++;
			} else if (c == 'x') {
				maskedNumber.append(c);
				index++;
			} else {
				maskedNumber.append(c);
			}
		}
		logger.info("Credit_Card :"+ maskedNumber.toString());
		return "Credit-card is masked";
	}

	/*------------MASKING--LOGIC --FOR--EMAIL-------------------------------------------*/

	public static String maskEmail(String strEmail, char maskChar)
			throws Exception{

		String[] parts = strEmail.split("@");
		//mask first part
		String strId = "";
		if(parts[0].length() < 1)
			strId = maskString(parts[0], 0, 2, '*');
		else
			strId = maskString(parts[0], 1, parts[0].length()-1, '*');
		//now append the domain part to the masked id part

		logger.info( "Email  = " +strId + "@" + parts[1]);
		return "Email is Masked Successfully ";
	}
	private static String maskString(String strText, int start, int end, char maskChar) 
			throws Exception{

		if(strText == null || strText.equals(""))
			return "";
		if(start < 3)
			start = 3;
		if( end > strText.length() )
			end = strText.length();
		if(start > end)
			throw new Exception("End index cannot be greater than start index");
		int maskLength = end - start;
		if(maskLength == 0)
			return strText;

		StringBuilder sbMaskString = new StringBuilder(maskLength);
		for(int i = 0; i < maskLength; i++){
			sbMaskString.append(maskChar);
		}
		return strText.substring(0, start) 
				+ sbMaskString.toString() 
				+ strText.substring(start + maskLength);
	}

	/*------------MASKING--LOGIC --FOR--PASSWORD-------------------------------------------*/

	public static String maskPassword(String password, int x) {
		int n = password.length()/x;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < password.length(); i++) {
			if (n >= 0 && (i < n || i >= (password.length() - n))) {
				sb.append(password.charAt(i));
			}
			else {
				sb.append("-");
			}
		}
		logger.info( "Password  = "+sb.toString());
		return "Password is masked Successfully";
	}

	public static String getMasking() throws Exception {
		logger.info("ID : "+UserData.id);
		logger.info("USERNAME : "+UserData.username);

		if(UserData.credit_card.length()==16) 
			maskCardNumber(UserData.credit_card, "xxxx-xxxx-xxxx-####");
		if(UserData.email.matches("([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\\.[a-zA-Z0-9_-]+)")) 
			maskEmail(UserData.email, '*');
		if(UserData.password.split("(?i)((?:password|pwd)(?::|=)(?:\\s*)[A-Za-z0-9@$!%*?&.;<>]+)") != null)
			maskPassword(UserData.password,20);

		return "mask";
	}
}

