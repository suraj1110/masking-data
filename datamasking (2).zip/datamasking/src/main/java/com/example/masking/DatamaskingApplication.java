package com.example.masking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.example.masking.entity.UserData;

@SpringBootApplication
public class DatamaskingApplication extends SpringBootServletInitializer{

	public static void main(String[] args) throws Exception {
		SpringApplication.run(DatamaskingApplication.class, args);
		
		
		//EmployeeData emp = new EmployeeData("1111111111111111", "fsffhdwhgef6511@gmail.com", "sdfasfas54d", "fasfsafgdsfefsaesefeac");
	}
}